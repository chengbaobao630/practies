package com.weimob.jingxuan.log.soa.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JingxuanLogJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(JingxuanLogJobApplication.class, args);
	}
}